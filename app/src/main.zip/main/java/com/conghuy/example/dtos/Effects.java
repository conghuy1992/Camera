package com.conghuy.example.dtos;

/**
 * Created by maidinh on 05-Oct-17.
 */

public class Effects {
    public String parameters = "";
    public boolean flag=false;
    public Effects(String parameters,boolean flag) {
        this.parameters = parameters;
        this.flag=flag;
    }
}
