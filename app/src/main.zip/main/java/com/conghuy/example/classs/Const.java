package com.conghuy.example.classs;

import android.content.Context;
import android.hardware.Camera;
import android.util.Log;
import android.view.Surface;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Created by maidinh on 04-Oct-17.
 */

public class Const {
    public static String TAG = "Const";

    public static int calculatePreviewOrientation(Camera.CameraInfo info, int rotation, Camera mCamera) {
        int degrees = 0;

        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }
        Log.d(TAG, "degrees:" + degrees);
        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + 360) % 360;
        }

//        Camera.Parameters params = mCamera.getParameters();
//        params.setRotation(result);
//        mCamera.setParameters(params);
        return result;
    }

    public static int getFrontFacingCamera() {
        int cameraId = -1;
        // Search for the front facing camera
        int numberOfCameras = Camera.getNumberOfCameras();
        for (int i = 0; i < numberOfCameras; i++) {
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(i, info);
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                cameraId = i;
                break;
            }
        }
        return cameraId;
    }

    public static void animaRotation(ImageView iv, int value) {
        iv.animate().rotation(value);
    }

    public static String getMsg(Context context, int id) {
        return context.getResources().getString(id);
    }

    public static void showMsg(Context context, int id) {
        Toast.makeText(context, getMsg(context, id), Toast.LENGTH_SHORT).show();
    }

    public static void showMsg(Context context, String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public static int getColor(Context context, int id) {
        return context.getResources().getColor(id);
    }
}
