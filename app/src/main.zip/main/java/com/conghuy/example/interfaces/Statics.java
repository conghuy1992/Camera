package com.conghuy.example.interfaces;

/**
 * Created by maidinh on 05-Oct-17.
 */

public interface Statics {
    String FOLDER = "CH Camera";
}
